__revision__ = "$Id: version.py 722 2010-03-08 14:14:34Z jeff.oneill $"

v = "1.6"
